export const config = { runtime: 'edge' };

const FEEDS = [
  {
    name: 'Indeed',
    url: 'https://nl.indeed.com/rss?q=systeembeheerder+OR+%22cloud+engineer%22+OR+%22devops+engineer%22+OR+%22system+engineer%22+OR+%22applicatiebeheerder%22+OR+%22werkplekbeheerder%22+OR+%22IT+manager%22&l=Amsterdam&jt=fulltime&radius=25'
  },
  {
    name: 'Nationale Vacaturebank',
    url: 'https://www.nationalevacaturebank.nl/vacature/rss?keywords=systeembeheerder+OR+cloud+engineer+OR+devops+OR+applicatiebeheerder+OR+werkplekbeheerder&location=Amsterdam&employmentType=fulltime'
  },
  {
    name: 'ITjobs.nl',
    url: 'https://www.itjobs.nl/rss/vacatures?zoekterm=systeembeheerder+OR+cloud+engineer+OR+devops+engineer&regio=amsterdam&dienstverband=vast'
  },
  {
    name: 'Jobbird',
    url: 'https://www.jobbird.com/nl/vacature-rss?q=systeembeheerder+cloud+engineer+devops&l=Amsterdam&contract=fulltime'
  }
];

const FREELANCE_KW = ['freelance','zzp','interim','opdracht','zelfstandig','contractor','zp '];

function parseXML(text) {
  const items = [];
  const itemMatches = text.matchAll(/<item>([\s\S]*?)<\/item>/g);
  for (const match of itemMatches) {
    const block = match[1];
    const get = (tag) => {
      const m = block.match(new RegExp(`<${tag}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${tag}>|<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`));
      return m ? (m[1] || m[2] || '').trim() : '';
    };
    items.push({
      title: get('title'),
      link: get('link'),
      description: get('description'),
      pubDate: get('pubDate'),
      company: get('source') || get('author') || ''
    });
  }
  return items;
}

function daysBack(pubDate) {
  if (!pubDate) return 3;
  const d = new Date(pubDate);
  if (isNaN(d)) return 3;
  return Math.max(0, Math.floor((Date.now() - d.getTime()) / 86400000));
}

function isFreelance(title, desc) {
  const text = (title + ' ' + desc).toLowerCase();
  return FREELANCE_KW.some(k => text.includes(k));
}

export default async function handler(req) {
  const results = await Promise.allSettled(
    FEEDS.map(async (feed) => {
      const res = await fetch(feed.url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; VacatureDashboard/1.0)',
          'Accept': 'application/rss+xml, application/xml, text/xml'
        },
        signal: AbortSignal.timeout(8000)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      const items = parseXML(text);
      return {
        source: feed.name,
        count: items.length,
        items: items
          .filter(i => i.title && !isFreelance(i.title, i.description))
          .map(i => ({
            title: i.title,
            link: i.link,
            source: feed.name,
            company: i.company,
            description: i.description.replace(/<[^>]+>/g, '').slice(0, 200),
            daysBack: daysBack(i.pubDate),
            pubDate: i.pubDate
          }))
      };
    })
  );

  const feeds = results.map((r, i) => ({
    name: FEEDS[i].name,
    ok: r.status === 'fulfilled',
    error: r.status === 'rejected' ? r.reason?.message : null,
    items: r.status === 'fulfilled' ? r.value.items : []
  }));

  const allItems = feeds.flatMap(f => f.items);

  return new Response(JSON.stringify({
    ok: true,
    fetched_at: new Date().toISOString(),
    total: allItems.length,
    sources: feeds.map(f => ({ name: f.name, ok: f.ok, count: f.items.length, error: f.error })),
    items: allItems.sort((a, b) => a.daysBack - b.daysBack)
  }), {
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 's-maxage=900, stale-while-revalidate=1800'
    }
  });
}
